const quotes = [
  {
    name: "1. Sentence",
    quote: "Hello There!",
  },
  {
    name: "2. Sentence",
    quote: "This is an example!",
  },
  {
    name: "3. Sentence",
    quote: "About JavaScript...",
  },
  {
    name: "4. Sentence",
    quote: "Life is a great teacher for getting mature :)",
  },
  {
    name: "5. Sentence",
    quote: " .....    ",
  },
  {
    name: "6. Sentence",
    quote: "Thank you!",
  },
];
const quoteBtn = document.querySelector("#quoteBtn");
const quoteAuthor = document.querySelector("#quoteAuthor");
const quote = document.querySelector("#quote");

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

var number = -1;
quoteBtn.addEventListener("click", (displayQuote) => {
  if (number == -1) {
    number = quotes.length - 1;
    shuffle(quotes);
  }
  quoteAuthor.innerHTML = quotes[number].name;
  quote.innerHTML = quotes[number].quote;
  number--;
});
